import flash.Lib;
import flash.display.Bitmap;
import flash.display.BitmapData;
import flash.display.DisplayObjectContainer;
import flash.display.Sprite;
import flash.events.Event;
import flash.events.KeyboardEvent;
import flash.events.MouseEvent;
import flash.text.TextField;
import flash.text.TextFieldType;
import flash.text.TextFormat;

@:bitmap("puddlebug.png") class Puddlebug extends BitmapData {}
@:bitmap("bramblewick.png") class Bramblewick extends BitmapData {}
@:bitmap("tangletoot.png") class Tangletoot extends BitmapData {}
@:bitmap("marsh.jpg") class Marsh extends BitmapData {}

class PocketBog extends Sprite {
    static inline var INK=0x342b46;
    static inline var IVORY=0xfff3cb;
    static inline var GOLD=0xffcc62;
    static inline var GREEN=0x9dd0a2;
    static inline var WHITE=0xfffbed;
    final species=["Puddlebug","Bramblewick","Tangletoot"];
    final descriptions=["Water beetle","Lantern moth","Rubberboot newt"];
    final homeLines=["Puddlebug is polishing its best lily pad.","Bramblewick is airing its copper wings.","Tangletoot is checking both rain boots."];
    final feedLines=["The berry disappears under a very smug lily pad.","Bramblewick nibbles the berry by lantern light.","A berry in each boot? Very well. Just this once."];
    final pictures:Array<BitmapData>;
    final marsh:BitmapData;
    final choices:Array<Sprite>=[];
    var page="";
    var pet=0;
    var berries=1;
    var seals=0;
    var notes="";
    var caught:Array<Bool>=[];
    var petPicture:Bitmap;
    var tick=0;
    var petY=0.0;
    var actions:Array<Void->Void>=[];
    var input:TextField;
    var formMessage:TextField;

    static function main(){ Lib.current.addChild(new PocketBog()); }

    function new(){
        super();
        pictures=[new Puddlebug(0,0),new Bramblewick(0,0),new Tangletoot(0,0)];
        marsh=new Marsh(0,0);
        addEventListener(Event.ADDED_TO_STAGE,function(_){
            stage.addEventListener(KeyboardEvent.KEY_DOWN,onKey);
            addEventListener(Event.ENTER_FRAME,animate);
            choose();
        });
    }
    function onKey(e:KeyboardEvent){
        if(stage.focus==input && input!=null){
            if(e.keyCode==13)restore();
            return;
        }
        var key=Std.int(e.keyCode);var ix=key>=97 && key<=99?key-97:key-49;
        if(ix>=0 && ix<actions.length && actions[ix]!=null)actions[ix]();
    }
    function animate(_){
        tick++;
        if(petPicture!=null)petPicture.y=petY+Math.sin(tick*0.07)*2;
        if(page=="hunt")for(i in 0...choices.length)if(!caught[i])choices[i].alpha=0.80+0.20*Math.sin(tick*0.09+i*2);
    }
    function wipe(name:String){
        while(numChildren>0)removeChildAt(0);
        graphics.clear();petPicture=null;input=null;page=name;actions=[];choices.resize(0);
        box(this,0,0,480,320,INK);
    }
    function box(parent:Sprite,x:Float,y:Float,w:Float,h:Float,color:Int,edge:Int=-1,radius:Float=0):Sprite {
        var p=new Sprite();p.x=x;p.y=y;parent.addChild(p);
        if(edge>=0)p.graphics.lineStyle(2,edge);
        p.graphics.beginFill(color);
        if(radius>0)p.graphics.drawRoundRect(0,0,w,h,radius,radius);
        else p.graphics.drawRect(0,0,w,h);
        p.graphics.endFill();return p;
    }
    function label(parent:DisplayObjectContainer,s:String,x:Float,y:Float,w:Float,h:Float,size:Int,color:Int=INK,bold:Bool=false,font:String="_sans",align:String="left"):TextField{
        var t=new TextField();t.x=x;t.y=y;t.width=w;t.height=h;t.selectable=false;t.mouseEnabled=false;
        t.defaultTextFormat=new TextFormat(font,size,color,bold,null,null,null,null,cast align);
        t.wordWrap=true;t.multiline=true;t.text=s;parent.addChild(t);return t;
    }
    function art(parent:Sprite,data:BitmapData,x:Float,y:Float,w:Float,h:Float):Bitmap {
        var b=new Bitmap(data);b.smoothing=true;
        var scale=Math.min(w/data.width,h/data.height);b.scaleX=b.scaleY=scale;
        b.x=x+(w-b.width)/2;b.y=y+(h-b.height)/2;parent.addChild(b);return b;
    }
    function button(parent:Sprite,s:String,x:Int,y:Int,w:Int,h:Int,fill:Int,fn:Void->Void):Sprite{
        box(parent,x+2,y+3,w,h,INK,-1,9);
        var b=box(parent,x,y,w,h,fill,INK,9);b.mouseChildren=false;b.buttonMode=true;
        b.graphics.lineStyle(1,WHITE,0.70);b.graphics.moveTo(5,3);b.graphics.lineTo(w-6,3);
        label(b,s,1,Math.floor((h-20)/2),w-2,25,14,INK,true,"_sans","center");
        b.addEventListener(MouseEvent.MOUSE_OVER,function(_)b.alpha=.88);
        b.addEventListener(MouseEvent.MOUSE_OUT,function(_)b.alpha=1);
        b.addEventListener(MouseEvent.CLICK,function(_)fn());return b;
    }
    function bar(kicker:String,heading:String){
        box(this,3,3,474,47,0x324b48,-1,9);
        label(this,kicker.toUpperCase(),14,4,432,14,9,0xeadc9b,true,"_typewriter");
        label(this,heading,13,15,454,35,24,WHITE,true,"_serif");
    }
    function choose(){
        wipe("choose");bar("Pocket Bog  /  Rainbarrel Pet Club","The adoption counter");
        box(this,4,53,472,263,IVORY,INK,9);
        label(this,"Pick a pocket-sized pal to earn your Mudkeeper seal.",12,57,456,26,14,INK,true);
        for(i in 0...3){
            var index=i;var x=12+i*154;
            var card=box(this,x,87,147,169,[0xd7e9c7,0xebd4b9,0xe7daae][i],INK,9);
            art(card,pictures[i],3,6,141,113);
            label(card,species[i],2,122,143,24,17,INK,true,"_serif","center");
            label(card,descriptions[i],2,146,143,18,12,INK,false,"_sans","center");
            var adopt=function(){pet=index;berries=1;seals=0;notes=homeLines[pet];habitat();};
            card.buttonMode=true;card.mouseChildren=false;card.addEventListener(MouseEvent.CLICK,function(_)adopt());actions.push(adopt);
        }
        button(this,"Enter a keeper code",257,274,200,26,GOLD,function()codeDesk(true));
        label(this,"Already have a pal?",15,274,234,27,16,INK,true,"_serif");
    }
    function stampCount():Int{return ((seals&1)>0?1:0)+((seals&2)>0?1:0)+((seals&4)>0?1:0);}
    function habitat(){
        wipe("habitat");bar("Pocket Bog  /  Rainbarrel Pet Club",species[pet]+"'s burrow");
        button(this,"Keeper code",350,12,111,25,GOLD,function()codeDesk(false));
        var scene=box(this,4,54,276,186,0x8ac6a3,INK,5);
        art(scene,marsh,0,0,276,186);
        petPicture=art(scene,pictures[pet],55,33,163,145);petY=petPicture.y;
        var panel=box(this,285,54,191,186,IVORY,INK,5);
        label(panel,"Keeper's log",9,5,175,26,19,INK,true,"_serif");
        label(panel,"BERRIES  x"+berries,10,33,173,22,13,0x803654,true,"_typewriter");
        var titles=["Forage the reeds","Feed your pal","Play lantern tag"];
        for(i in 0...3){
            var y=62+i*25;var got=(seals&(1<<i))!=0;
            box(panel,11,y,15,15,got?GREEN:WHITE,INK,4);
            if(got)label(panel,"x",11,y-4,15,20,16,INK,true,"_sans","center");
            label(panel,titles[i],32,y-4,153,23,13,INK,got);
        }
        label(panel,stampCount()==3?"MUDKEEPER SEAL":"Stamps  "+stampCount()+" / 3",9,147,173,32,stampCount()==3?14:16,0x6a3752,true,"_serif");
        box(this,4,244,472,31,WHITE,INK,5);
        label(this,notes,10,248,460,24,12,INK,false);
        actions=[forage,feed,startHunt];
        button(this,"1   Forage",7,281,149,31,GREEN,forage);
        button(this,"2   Feed",164,281,149,31,GOLD,feed);
        button(this,"3   Play tag",321,281,149,31,0xe7b1a6,startHunt);
    }
    function forage(){
        if(berries>=9){notes="The berry tin is full. Time for a snack.";habitat();return;}
        var found=Std.int(Math.min(2,9-berries));berries+=found;seals|=1;
        notes="Under the teacup: "+found+" bogberr"+(found==1?"y!":"ies!");habitat();
    }
    function feed(){
        if(berries==0){notes="The berry tin is empty. Try the reeds.";habitat();return;}
        berries--;seals|=2;notes=feedLines[pet];habitat();
    }
    function startHunt(){caught=[false,false,false];hunt();}
    function hunt(){
        wipe("hunt");bar("Field game  /  Lantern tag","Catch three lantern flies");
        art(this,marsh,4,52,472,224);
        label(this,"Tap a glowing fly, or press its number.",8,279,323,25,14,WHITE,true);
        button(this,"Burrow",361,281,106,28,GOLD,function(){notes=homeLines[pet];habitat();});
        var xs=[80,228,355],ys=[137,77,172];
        for(i in 0...3){
            var ix=i;
            var b=new Sprite();b.x=xs[i];b.y=ys[i];addChild(b);
            b.graphics.beginFill(0xffdc55,.28);b.graphics.drawCircle(0,0,25);b.graphics.endFill();
            for(sign in [-1,1]){
                b.graphics.lineStyle(2,INK);b.graphics.beginFill(0xc7f6d5);
                b.graphics.drawEllipse(sign<0?-23:2,-16,19,12);b.graphics.endFill();
            }
            b.graphics.beginFill(GOLD);b.graphics.drawCircle(0,0,12);b.graphics.endFill();
            label(b,Std.string(i+1),-11,-12,22,24,16,INK,true,"_sans","center");
            b.mouseChildren=false;b.buttonMode=true;b.visible=!caught[i];choices.push(b);
            var take=function(){
                if(caught[ix])return;
                caught[ix]=true;b.visible=false;
                if(caught.indexOf(false)<0){seals|=4;notes="Three lantern flies! "+species[pet]+" takes a victory lap.";habitat();}
            };
            actions.push(take);b.addEventListener(MouseEvent.CLICK,function(_)take());
        }
    }
    function keeperCode():String{
        var digits=Std.string(pet+1)+Std.string(berries)+Std.string(seals);
        return "BOG-"+digits+Std.string(((pet+1)*3+berries*7+seals*9)%10);
    }
    function codeDesk(enter:Bool){
        wipe("code");bar("Pocket Bog  /  Rainbarrel Pet Club","Keeper passport");
        box(this,4,53,472,262,IVORY,INK,8);
        var title=enter?"Bring back your pal":"Take your pal with you";
        label(this,title,18,69,440,35,22,INK,true,"_serif");
        label(this,enter?"Enter the four digits from your keeper code.":"Write down this code. It keeps your pet, your berry tin and your three stamps.",18,108,435,57,16);
        box(this,24,enter?147:166,431,enter?44:59,WHITE,INK,8);
        if(enter){
            label(this,"BOG-",36,148,95,43,29,INK,true,"_typewriter");
            input=label(this,"",134,148,173,43,29,0x69374f,true,"_typewriter");
            input.mouseEnabled=true;input.type=TextFieldType.INPUT;input.restrict="0-9";input.maxChars=4;input.selectable=true;stage.focus=input;
            button(this,"Clear",363,156,75,24,IVORY,function(){input.text="";stage.focus=input;});
            for(i in 0...10){
                var digit=Std.string(i);
                button(this,digit,16+i*45,198,40,32,GREEN,function(){
                    if(input.text.length<4)input.text+=digit;
                    stage.focus=input;input.setSelection(input.text.length,input.text.length);
                });
            }
            formMessage=label(this,"",19,236,428,30,14,0x862f4e,true);
            button(this,"Adoption counter",20,272,187,30,GREEN,choose);
            button(this,"Restore keeper",242,272,200,30,GOLD,restore);
        }else{
            label(this,keeperCode(),24,172,431,49,31,INK,true,"_typewriter","center");
            button(this,"Adoption counter",20,272,187,30,GREEN,choose);
            button(this,"Back to burrow",242,272,200,30,GOLD,habitat);
        }
    }
    function restore(){
        if(input==null)return;
        var digits=input.text;var n=Std.parseInt(digits);
        if(!~/^[1-3][0-9][0-7][0-9]$/.match(digits)||n==null){formMessage.text="Use the four digits printed after BOG-.";return;}
        var p=Std.parseInt(digits.charAt(0)),b=Std.parseInt(digits.charAt(1)),s=Std.parseInt(digits.charAt(2)),k=Std.parseInt(digits.charAt(3));
        if((p*3+b*7+s*9)%10!=k){formMessage.text="That seal doesn't match. Check the four digits.";return;}
        pet=p-1;berries=b;seals=s;notes="Welcome back, Mudkeeper. Your pal remembers you.";stage.focus=null;habitat();
    }
}
