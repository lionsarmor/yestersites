Pocket Bog — Rainbarrel Pet Club

Install Haxe 4.3.3 or compatible. Open a terminal in this folder and run:

  haxe build.hxml

The build creates pocket-bog.swf. In Retro Page, add a Flash movie object, select the SWF and give the game a classic-edition description.

Edit the script or replace the four pictures and rebuild to make your own version.
